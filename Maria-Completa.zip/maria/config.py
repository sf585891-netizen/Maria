"""
Maria - Configurações centrais
"""
from pathlib import Path
from datetime import datetime

# Diretórios
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
MEMORY_FILE = DATA_DIR / "memory.json"
KNOWLEDGE_INDEX = DATA_DIR / "knowledge_index.json"
VERSION_FILE = DATA_DIR / "version.json"
LOG_FILE = DATA_DIR / "maria.log"

# Garante que as pastas existam
DATA_DIR.mkdir(exist_ok=True)
KNOWLEDGE_DIR.mkdir(exist_ok=True)

# Versão atual da Maria
MARIA_VERSION = "0.9.2-alpha"
MARIA_CODENAME = "Voz + Câmera"

# Idioma padrão
DEFAULT_LANGUAGE = "pt-BR"

# Configurações de segurança de hardware e dispositivos
HARDWARE_ENABLED = False          # Só ativa com hardware real e autorização
ALLOW_MOTOR_CONTROL = False
ALLOW_GPIO = False
ALLOW_NETWORK_DEVICES = True      # Permite registrar e testar dispositivos de rede
ALLOW_SERIAL = True               # Permite listar/conectar portas seriais
MAX_MOTOR_SPEED = 0.3             # 30% de potência máxima por segurança
NETWORK_SCAN_ENABLED = False      # Varredura de rede desativada por padrão (pode ser lenta/invasiva)

# Configurações de busca
SEARCH_MAX_RESULTS = 5
SEARCH_TIMEOUT = 10

# Autoaperfeiçoamento
SELF_IMPROVE_ENABLED = True
MAX_IMPROVEMENT_HISTORY = 50

# Status
def get_status():
    return {
        "name": "Maria",
        "version": MARIA_VERSION,
        "codename": MARIA_CODENAME,
        "status": "ONLINE",
        "language": DEFAULT_LANGUAGE,
        "hardware": "DESATIVADO" if not HARDWARE_ENABLED else "ATIVO",
        "timestamp": datetime.now().isoformat()
    }
