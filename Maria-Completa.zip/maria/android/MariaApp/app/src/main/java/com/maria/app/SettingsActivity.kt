package com.maria.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Configurações da Maria"

        val editUrl = findViewById<EditText>(R.id.editServerUrl)
        val btnSave = findViewById<Button>(R.id.btnSave)

        val prefs = getSharedPreferences("maria_prefs", MODE_PRIVATE)
        editUrl.setText(prefs.getString("server_url", "http://192.168.1.15:8000"))

        btnSave.setOnClickListener {
            var url = editUrl.text.toString().trim()
            if (url.isEmpty()) {
                Toast.makeText(this, "Digite um endereço válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://$url"
            }
            prefs.edit().putString("server_url", url).apply()
            Toast.makeText(this, "Salvo! Reinicie o app para aplicar.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
