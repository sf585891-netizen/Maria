package com.maria.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (!allGranted) {
            Toast.makeText(
                this,
                "Microfone e câmera são necessários para voz e visão da Maria",
                Toast.LENGTH_LONG
            ).show()
        }
        loadMaria()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        setupWebView()
        checkPermissionsAndLoad()
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.userAgentString = settings.userAgentString + " MariaApp/0.9.2"
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_ON)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    showOfflinePage()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    runOnUiThread {
                        it.grant(it.resources)
                    }
                }
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(
                    Intent.createChooser(intent, "Escolher imagem"),
                    FILE_CHOOSER_REQUEST
                )
                return true
            }
        }
    }

    private fun checkPermissionsAndLoad() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            loadMaria()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    private fun loadMaria() {
        val prefs = getSharedPreferences("maria_prefs", MODE_PRIVATE)
        val serverUrl = prefs.getString("server_url", DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        webView.loadUrl(serverUrl)
    }

    private fun showOfflinePage() {
        val html = """
            <!DOCTYPE html>
            <html lang="pt-BR">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Maria Offline</title>
                <style>
                    body {
                        font-family: system-ui, sans-serif;
                        background: #0b0f19;
                        color: #e2e8f0;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        min-height: 100vh;
                        margin: 0;
                        padding: 24px;
                        text-align: center;
                    }
                    .logo {
                        width: 80px; height: 80px;
                        background: linear-gradient(135deg, #38bdf8, #818cf8);
                        border-radius: 20px;
                        display: flex; align-items: center; justify-content: center;
                        font-size: 40px;
                        margin-bottom: 20px;
                    }
                    h1 { font-size: 1.5rem; margin-bottom: 8px; }
                    p { color: #94a3b8; line-height: 1.5; max-width: 320px; }
                    .box {
                        background: #121826;
                        border: 1px solid #1e293b;
                        border-radius: 12px;
                        padding: 16px;
                        margin-top: 24px;
                        text-align: left;
                        font-size: 0.9rem;
                        max-width: 340px;
                    }
                    code {
                        background: #0b0f19;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 0.85rem;
                    }
                    button {
                        margin-top: 24px;
                        background: linear-gradient(135deg, #38bdf8, #818cf8);
                        color: #0b0f19;
                        border: none;
                        padding: 14px 28px;
                        border-radius: 12px;
                        font-size: 1rem;
                        font-weight: 600;
                    }
                </style>
            </head>
            <body>
                <div class="logo">🤖</div>
                <h1>Maria não encontrada</h1>
                <p>Não consegui conectar ao servidor da Maria.</p>
                <div class="box">
                    <strong>Como resolver:</strong><br><br>
                    1. No computador, rode:<br>
                    <code>python main.py</code><br><br>
                    2. Descubra o IP do computador<br>
                    (ex: 192.168.1.15)<br><br>
                    3. No app, abra Configurações e coloque:<br>
                    <code>http://SEU-IP:8000</code>
                </div>
                <button onclick="location.reload()">Tentar novamente</button>
            </body>
            </html>
        """.trimIndent()
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (data == null || resultCode != RESULT_OK) null
            else arrayOf(Uri.parse(data.dataString))
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    companion object {
        // Altere este IP para o IP do seu computador na rede
        private const val DEFAULT_SERVER_URL = "http://192.168.1.15:8000"
        private const val FILE_CHOOSER_REQUEST = 1001
    }
}
