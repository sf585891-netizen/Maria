package com.maria.app.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import com.maria.app.MainActivity
import com.maria.app.R
import java.util.*

/**
 * Serviço em primeiro plano que mantém a Maria ouvindo e falando
 * mesmo quando o usuário está em outros aplicativos.
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isListening = false
    private var isTtsReady = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this, this)
        setupSpeechRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startVoiceMode()
            ACTION_STOP -> stopVoiceMode()
            ACTION_SPEAK -> {
                val text = intent.getStringExtra(EXTRA_TEXT) ?: return START_STICKY
                speak(text)
            }
        }
        return START_STICKY
    }

    private fun startVoiceMode() {
        val notification = buildNotification("Maria está ouvindo...")
        startForeground(NOTIFICATION_ID, notification)
        startListening()
        Log.d(TAG, "Modo voz ativado")
    }

    private fun stopVoiceMode() {
        stopListening()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.d(TAG, "Modo voz desativado")
    }

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "Reconhecimento de voz não disponível")
            return
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {
                updateNotification("Ouvindo...")
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                Log.w(TAG, "Erro reconhecimento: $error")
                // Reinicia a escuta automaticamente
                if (isListening) {
                    android.os.Handler(mainLooper).postDelayed({ startListening() }, 800)
                }
            }

            override fun onResults(results: android.os.Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    Log.d(TAG, "Usuário disse: $text")
                    // Envia o texto para processamento (broadcast)
                    val intent = Intent(ACTION_VOICE_RESULT).apply {
                        putExtra(EXTRA_TEXT, text)
                        setPackage(packageName)
                    }
                    sendBroadcast(intent)
                    updateNotification("Processando: $text")
                }
                // Continua ouvindo
                if (isListening) {
                    android.os.Handler(mainLooper).postDelayed({ startListening() }, 600)
                }
            }

            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
    }

    private fun startListening() {
        if (speechRecognizer == null) return
        isListening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao iniciar escuta", e)
        }
    }

    private fun stopListening() {
        isListening = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao parar escuta", e)
        }
    }

    fun speak(text: String) {
        if (!isTtsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maria_utterance")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("pt", "BR")
            isTtsReady = true
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Maria Voz",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Maria está ativa em modo voz"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤖 Maria")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopPending)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopListening()
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "MariaVoiceService"
        const val CHANNEL_ID = "maria_voice_channel"
        const val NOTIFICATION_ID = 19001

        const val ACTION_START = "com.maria.app.START_VOICE"
        const val ACTION_STOP = "com.maria.app.STOP_VOICE"
        const val ACTION_SPEAK = "com.maria.app.SPEAK"
        const val ACTION_VOICE_RESULT = "com.maria.app.VOICE_RESULT"
        const val EXTRA_TEXT = "text"
    }
}
