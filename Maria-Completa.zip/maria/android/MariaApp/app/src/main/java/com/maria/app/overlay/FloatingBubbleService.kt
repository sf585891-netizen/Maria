package com.maria.app.overlay

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import com.maria.app.MainActivity
import com.maria.app.R
import com.maria.app.service.VoiceService
import kotlin.math.abs

/**
 * Bolha flutuante da Maria no canto da tela.
 * Permanece visível em cima de outros aplicativos.
 */
class FloatingBubbleService : Service() {

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var isVoiceActive = false

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.END
        params.x = 24
        params.y = 200

        // Arrastar a bolha
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        bubbleView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) isClick = false
                    params.x = initialX - dx
                    params.y = initialY + dy
                    windowManager?.updateViewLayout(bubbleView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        onBubbleClick()
                    }
                    true
                }
                else -> false
            }
        }

        // Clique longo = ativar/desativar modo voz
        bubbleView?.setOnLongClickListener {
            toggleVoiceMode()
            true
        }

        try {
            windowManager?.addView(bubbleView, params)
        } catch (e: Exception) {
            Toast.makeText(this, "Permissão de sobreposição necessária", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun onBubbleClick() {
        // Abre o app principal
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }

    private fun toggleVoiceMode() {
        val intent = Intent(this, VoiceService::class.java)
        if (isVoiceActive) {
            intent.action = VoiceService.ACTION_STOP
            startService(intent)
            isVoiceActive = false
            updateBubbleAppearance(false)
            Toast.makeText(this, "Maria: modo voz desligado", Toast.LENGTH_SHORT).show()
        } else {
            intent.action = VoiceService.ACTION_START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            isVoiceActive = true
            updateBubbleAppearance(true)
            Toast.makeText(this, "Maria: modo voz ligado — pode falar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateBubbleAppearance(active: Boolean) {
        val icon = bubbleView?.findViewById<ImageView>(R.id.bubbleIcon)
        // Muda visual quando está ouvindo
        icon?.alpha = if (active) 1.0f else 0.85f
        icon?.scaleX = if (active) 1.15f else 1.0f
        icon?.scaleY = if (active) 1.15f else 1.0f
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {}
        }
        bubbleView = null
    }

    companion object {
        const val ACTION_SHOW = "com.maria.app.SHOW_BUBBLE"
        const val ACTION_HIDE = "com.maria.app.HIDE_BUBBLE"
    }
}
