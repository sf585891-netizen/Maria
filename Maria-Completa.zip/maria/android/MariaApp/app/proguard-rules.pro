# Maria App - ProGuard rules
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
