# 🤖 Maria — App Android (APK)

Versão do app: **0.9.2**

Este é o projeto Android da Maria. Ele abre a interface da Maria em um WebView nativo, com permissões de **microfone** e **câmera**.

---

## 📱 Como gerar o APK

### Pré-requisitos
- [Android Studio](https://developer.android.com/studio) instalado
- Computador com a Maria rodando (`python main.py`)

### Passos

1. Abra o Android Studio
2. **File → Open** e selecione a pasta:
   ```
   maria/android/MariaApp
   ```
3. Aguarde o Gradle sincronizar (pode demorar na primeira vez)
4. Conecte um celular Android por USB (com depuração USB ativada) **ou** use um emulador
5. Clique no botão verde **Run** ▶

### Gerar APK para instalar em qualquer celular

1. No Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Quando terminar, clique em **locate**
3. O arquivo `app-debug.apk` estará pronto
4. Passe o APK para o celular e instale (ative “Fontes desconhecidas” se pedir)

---

## ⚙️ Configurar o endereço da Maria

O app precisa saber onde o servidor da Maria está rodando.

1. No computador, rode:
   ```bash
   python main.py
   ```
2. Descubra o IP do computador na rede Wi-Fi (ex: `192.168.1.15`)
3. No código, abra:
   ```
   app/src/main/java/com/maria/app/MainActivity.kt
   ```
4. Altere a linha:
   ```kotlin
   private const val DEFAULT_SERVER_URL = "http://192.168.1.15:8000"
   ```
   para o IP correto do seu computador.

Celular e computador precisam estar na **mesma rede Wi-Fi**.

---

## ✅ O que o APK já tem

- Interface completa da Maria
- Microfone (falar com a Maria)
- Câmera
- Teclado
- Funciona em tela cheia
- Página de erro amigável se o servidor estiver offline

---

## ⚠️ Limitações atuais

- Ainda não é um app 100% offline (precisa do servidor Python rodando)
- Não acompanha outros aplicativos (isso exige Accessibility Service + políticas rígidas da Play Store)
- Para publicar na Play Store seria necessário conta de desenvolvedor e mais configurações de segurança

---

## Próximos passos possíveis

- Embutir um servidor local no APK (mais avançado)
- Ícone personalizado
- Notificações
- Inicialização automática

---

Feito para o projeto Maria ❤️
