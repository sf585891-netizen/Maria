"""
Domínios de conhecimento da Maria
"""
