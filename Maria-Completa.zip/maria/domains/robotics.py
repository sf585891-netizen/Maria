"""
Módulo de Robótica da Maria
Conhecimento e utilitários básicos (expandível).
"""
from typing import Dict, List, Tuple
import math


class RoboticsKnowledge:
    """Conhecimento estruturado de robótica."""

    @staticmethod
    def forward_kinematics_2d(l1: float, l2: float, theta1: float, theta2: float) -> Tuple[float, float]:
        """
        Cinemática direta de um braço planar de 2 graus de liberdade.
        theta em radianos.
        Retorna (x, y) do end-effector.
        """
        x = l1 * math.cos(theta1) + l2 * math.cos(theta1 + theta2)
        y = l1 * math.sin(theta1) + l2 * math.sin(theta1 + theta2)
        return x, y

    @staticmethod
    def inverse_kinematics_2d(l1: float, l2: float, x: float, y: float) -> List[Tuple[float, float]]:
        """
        Cinemática inversa 2D (soluções possíveis).
        Retorna lista de (theta1, theta2) em radianos.
        """
        d = math.hypot(x, y)
        if d > l1 + l2 or d < abs(l1 - l2):
            return []  # Inalcançável

        cos_theta2 = (x**2 + y**2 - l1**2 - l2**2) / (2 * l1 * l2)
        cos_theta2 = max(-1.0, min(1.0, cos_theta2))
        theta2_a = math.acos(cos_theta2)
        theta2_b = -theta2_a

        solutions = []
        for theta2 in (theta2_a, theta2_b):
            k1 = l1 + l2 * math.cos(theta2)
            k2 = l2 * math.sin(theta2)
            theta1 = math.atan2(y, x) - math.atan2(k2, k1)
            solutions.append((theta1, theta2))
        return solutions

    @staticmethod
    def explain_pid() -> str:
        return (
            "**Controlador PID**\n\n"
            "O PID é um dos controladores mais usados em robótica:\n\n"
            "• **P (Proporcional)**: reage ao erro atual\n"
            "• **I (Integral)**: elimina erro residual acumulado\n"
            "• **D (Derivativo)**: amortece a resposta (prevê o futuro)\n\n"
            "Fórmula:\n"
            "u(t) = Kp·e(t) + Ki·∫e(t)dt + Kd·de/dt\n\n"
            "Usado em motores, drones, braços robóticos e temperatura."
        )

    @staticmethod
    def explain_slam() -> str:
        return (
            "**SLAM — Simultaneous Localization and Mapping**\n\n"
            "O robô constrói um mapa do ambiente **ao mesmo tempo** que se localiza nele.\n\n"
            "Componentes principais:\n"
            "• Sensores (LiDAR, câmera, IMU, odometria)\n"
            "• Frontend (extração de features / scan matching)\n"
            "• Backend (otimização de grafo / filtro de partículas)\n"
            "• Loop closure (reconhecer lugares já visitados)\n\n"
            "Bibliotecas populares: Cartographer, ORB-SLAM, RTAB-Map, GMapping."
        )
