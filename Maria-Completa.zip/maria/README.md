# 🤖 Maria — Assistente IA Pessoal + Conhecimento + Robótica

Versão atual: **0.9.0-alpha (Núcleo)**

A Maria é uma assistente de IA pessoal + plataforma de conhecimento + sistema de robótica.  
Este repositório contém o **núcleo funcional** pronto para rodar e expandir.

---

## 🚀 Como rodar (agora mesmo)

```bash
cd maria
pip install -r requirements.txt
python main.py
```

Depois abra no navegador:

**http://127.0.0.1:8000**

---

## ✅ O que já funciona

| Módulo              | Status     | Descrição                                      |
|---------------------|------------|------------------------------------------------|
| Chat inteligente    | ✅ Pronto  | Detecta intenções e responde em português      |
| Memória persistente | ✅ Pronto  | Salva conversas e fatos importantes            |
| Pesquisa na web     | ✅ Pronto  | DuckDuckGo real (sem chave de API)             |
| Currículo científico| ✅ Pronto  | Robótica, Física, Química, Biologia, Prog...   |
| Autoaperfeiçoamento | ✅ Pronto  | Registro de propostas de melhoria              |
| Interface web       | ✅ Pronto  | Chat moderno + painel lateral                  |
| Camada de hardware  | 🔒 Segura  | Desativada por padrão (segurança)              |
| Simulação           | ✅ Stub    | Cinemática 2D de braço robótico                |
| Módulo de robótica  | ✅ Pronto  | Cinemática direta/inversa + explicações        |

---

## 📁 Estrutura do projeto

```
maria/
├── main.py                 # Ponto de entrada (FastAPI)
├── config.py               # Configurações centrais
├── requirements.txt
├── core/
│   ├── agent.py            # Cérebro da Maria
│   ├── memory.py           # Memória de conversas
│   ├── search.py           # Pesquisa na internet
│   ├── knowledge.py        # Base de conhecimento
│   └── self_improve.py     # Autoaperfeiçoamento
├── domains/
│   └── robotics.py         # Conhecimento de robótica
├── hardware/               # Controle seguro de hardware
├── simulation/             # Simulações antes do físico
├── templates/
│   └── index.html          # Interface web
└── data/                   # Memória e logs (gerado automaticamente)
```

---

## 🧠 Como a Maria pensa (ciclo)

```
Você fala
    ↓
Detecta intenção
    ↓
Memória + Conhecimento + Pesquisa (se necessário)
    ↓
Resposta
    ↓
Salva na memória
```

---

## 🔒 Segurança de Hardware

Por padrão **tudo está desativado**:

- `HARDWARE_ENABLED = False`
- `ALLOW_MOTOR_CONTROL = False`
- Velocidade máxima limitada a 30%

Nunca ligue motores diretamente. Sempre passe pela camada de segurança.

---

## 🛣️ Próximos passos (roadmap)

1. Adicionar voz (TTS/STT)
2. Integrar modelo de linguagem local (quando houver GPU/recursos)
3. App Android (Flutter ou Kotlin)
4. App Desktop (Electron ou PyQt)
5. Mais simulações (PyBullet / MuJoCo)
6. Site oficial com downloads
7. Sistema de versões e rollback automático

---

## ❤️ Filosofia

A Maria **não** finge saber tudo.  
Ela pesquisa → organiza → verifica → memoriza → usa → testa → melhora.

Começamos pequeno e sólido. Depois expandimos sem quebrar o que já funciona.

---

Feito com carinho para o projeto Maria.
