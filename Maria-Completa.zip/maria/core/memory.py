"""
Sistema de Memória da Maria
Guarda conversas importantes e conhecimento adquirido.
"""
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import config


class Memory:
    def __init__(self, memory_file: Path = config.MEMORY_FILE):
        self.memory_file = memory_file
        self.conversations: List[Dict] = []
        self.important_facts: List[Dict] = []
        self._load()

    def _load(self):
        if self.memory_file.exists() and self.memory_file.stat().st_size > 0:
            try:
                with open(self.memory_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.conversations = data.get("conversations", [])
                    self.important_facts = data.get("important_facts", [])
            except Exception as e:
                print(f"[Memória] Erro ao carregar: {e}")
                self.conversations = []
                self.important_facts = []
        else:
            self.conversations = []
            self.important_facts = []

    def _save(self):
        try:
            data = {
                "conversations": self.conversations[-200:],  # Limita histórico
                "important_facts": self.important_facts[-100:],
                "last_updated": datetime.now().isoformat()
            }
            with open(self.memory_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Memória] Erro ao salvar: {e}")

    def add_message(self, role: str, content: str, important: bool = False):
        msg = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "important": important
        }
        self.conversations.append(msg)
        if important:
            self.important_facts.append({
                "content": content,
                "timestamp": msg["timestamp"]
            })
        self._save()

    def get_recent(self, n: int = 10) -> List[Dict]:
        return self.conversations[-n:]

    def get_context(self, max_chars: int = 3000) -> str:
        """Retorna contexto recente formatado para o agente."""
        recent = self.get_recent(12)
        lines = []
        total = 0
        for msg in reversed(recent):
            line = f"{msg['role'].upper()}: {msg['content']}"
            if total + len(line) > max_chars:
                break
            lines.insert(0, line)
            total += len(line)
        return "\n".join(lines)

    def search_memory(self, query: str) -> List[Dict]:
        query_lower = query.lower()
        results = []
        for msg in self.conversations:
            if query_lower in msg["content"].lower():
                results.append(msg)
        return results[-10:]

    def clear(self):
        self.conversations = []
        self.important_facts = []
        self._save()

    def stats(self) -> Dict:
        return {
            "total_messages": len(self.conversations),
            "important_facts": len(self.important_facts),
            "last_message": self.conversations[-1]["timestamp"] if self.conversations else None
        }
