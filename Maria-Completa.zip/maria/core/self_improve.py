"""
Sistema de Autoaperfeiçoamento da Maria
Ciclo: Analisar → Encontrar problema → Propor melhoria → Registrar
"""
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import config


class SelfImprovement:
    def __init__(self):
        self.history_file = config.DATA_DIR / "improvements.json"
        self.history: List[Dict] = []
        self._load()

    def _load(self):
        if self.history_file.exists():
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    self.history = json.load(f)
            except Exception:
                self.history = []

    def _save(self):
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.history[-config.MAX_IMPROVEMENT_HISTORY:], f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[SelfImprove] Erro ao salvar: {e}")

    def propose(self, problem: str, proposal: str, area: str = "geral") -> Dict:
        """Registra uma proposta de melhoria."""
        entry = {
            "id": len(self.history) + 1,
            "timestamp": datetime.now().isoformat(),
            "area": area,
            "problem": problem,
            "proposal": proposal,
            "status": "proposta",  # proposta | testando | aprovada | rejeitada
            "version_before": config.MARIA_VERSION
        }
        self.history.append(entry)
        self._save()
        return entry

    def list_proposals(self, status: Optional[str] = None) -> List[Dict]:
        if status:
            return [h for h in self.history if h["status"] == status]
        return self.history

    def approve(self, proposal_id: int) -> bool:
        for h in self.history:
            if h["id"] == proposal_id:
                h["status"] = "aprovada"
                h["approved_at"] = datetime.now().isoformat()
                self._save()
                return True
        return False

    def get_summary(self) -> str:
        total = len(self.history)
        approved = len([h for h in self.history if h["status"] == "aprovada"])
        pending = len([h for h in self.history if h["status"] == "proposta"])
        return (
            f"🔧 **Sistema de Autoaperfeiçoamento**\n"
            f"Total de propostas: {total}\n"
            f"Aprovadas: {approved}\n"
            f"Pendentes: {pending}\n"
            f"Versão atual: {config.MARIA_VERSION}"
        )
