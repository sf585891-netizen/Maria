"""
Base de Conhecimento da Maria
Organiza o currículo científico e permite consultas.
"""
from typing import Dict, List, Optional
from pathlib import Path
import json
import config


class KnowledgeBase:
    def __init__(self):
        self.domains = self._build_domains()
        self.index_file = config.KNOWLEDGE_INDEX
        self._ensure_index()

    def _build_domains(self) -> Dict:
        """Currículo científico completo da Maria (conforme visão)."""
        return {
            "robotica": {
                "nome": "Robótica",
                "emoji": "🤖",
                "topicos": [
                    "braços robóticos", "robôs móveis", "humanoides", "drones",
                    "cinemática", "dinâmica", "sensores", "atuadores",
                    "controle", "navegação", "SLAM", "planejamento de movimento",
                    "manipulação", "ROS", "kinematics", "inverse kinematics"
                ],
                "descricao": "Tudo sobre robôs: do braço industrial ao humanoide."
            },
            "eletricidade": {
                "nome": "Eletricidade e Eletrônica",
                "emoji": "⚡",
                "topicos": [
                    "tensão", "corrente", "potência", "circuitos", "motores",
                    "sensores", "microcontroladores", "eletrônica digital",
                    "eletrônica de potência", "baterias", "sistemas embarcados",
                    "Arduino", "ESP32", "Raspberry Pi", "PWM", "PID"
                ],
                "descricao": "Fundamentos elétricos e eletrônicos para controlar o mundo físico."
            },
            "fisica_nuclear": {
                "nome": "Física Atômica e Nuclear",
                "emoji": "⚛️",
                "topicos": [
                    "estrutura atômica", "isótopos", "radioatividade", "radiação",
                    "fissão", "fusão", "física nuclear", "proteção radiológica",
                    "aplicações civis da energia nuclear", "decadimento", "meia-vida"
                ],
                "descricao": "Estrutura da matéria e energia nuclear."
            },
            "fisica": {
                "nome": "Física",
                "emoji": "🔬",
                "topicos": [
                    "mecânica", "termodinâmica", "eletromagnetismo", "óptica",
                    "física quântica", "relatividade", "astrofísica",
                    "leis de Newton", "energia", "momento", "ondas"
                ],
                "descricao": "Leis fundamentais do universo."
            },
            "quimica": {
                "nome": "Química",
                "emoji": "🧪",
                "topicos": [
                    "átomos", "moléculas", "reações", "materiais", "eletroquímica",
                    "polímeros", "nanomateriais", "corrosão", "estequiometria",
                    "tabela periódica", "ligações químicas"
                ],
                "descricao": "Composição e transformação da matéria."
            },
            "biologia": {
                "nome": "Plantas e Biologia",
                "emoji": "🌱",
                "topicos": [
                    "anatomia vegetal", "fotossíntese", "raízes", "folhas", "flores",
                    "sementes", "genética", "reprodução", "fisiologia", "doenças",
                    "ecologia", "relação planta-solo", "cultivo", "agricultura",
                    "biodiversidade", "célula", "DNA"
                ],
                "descricao": "Vida vegetal e biologia geral."
            },
            "programacao": {
                "nome": "Programação",
                "emoji": "💻",
                "topicos": [
                    "Python", "JavaScript", "C", "C++", "Java", "Kotlin",
                    "HTML", "CSS", "SQL", "scripts", "automação",
                    "análise de código", "testes", "depuração", "Git",
                    "algoritmos", "estruturas de dados"
                ],
                "descricao": "Assistente de programação e automação."
            }
        }

    def _ensure_index(self):
        if not self.index_file.exists():
            self._save_index()

    def _save_index(self):
        data = {
            "domains": {k: {
                "nome": v["nome"],
                "emoji": v["emoji"],
                "topicos_count": len(v["topicos"]),
                "descricao": v["descricao"]
            } for k, v in self.domains.items()},
            "total_domains": len(self.domains)
        }
        with open(self.index_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def list_domains(self) -> List[Dict]:
        return [
            {
                "id": k,
                "nome": v["nome"],
                "emoji": v["emoji"],
                "topicos": len(v["topicos"]),
                "descricao": v["descricao"]
            }
            for k, v in self.domains.items()
        ]

    def get_domain(self, domain_id: str) -> Optional[Dict]:
        return self.domains.get(domain_id.lower())

    def search_topics(self, query: str) -> List[Dict]:
        query_lower = query.lower()
        results = []
        for domain_id, domain in self.domains.items():
            for topic in domain["topicos"]:
                if query_lower in topic.lower() or query_lower in domain["nome"].lower():
                    results.append({
                        "domain": domain["nome"],
                        "emoji": domain["emoji"],
                        "topic": topic,
                        "domain_id": domain_id
                    })
        return results

    def get_curriculum_summary(self) -> str:
        lines = ["📚 **Currículo Científico da Maria**\n"]
        for d in self.list_domains():
            lines.append(f"{d['emoji']} **{d['nome']}** — {d['topicos']} tópicos")
            lines.append(f"   {d['descricao']}\n")
        return "\n".join(lines)

    def explain_topic(self, topic: str) -> str:
        """Retorna uma explicação básica + indicação de domínio (placeholder para expansão)."""
        matches = self.search_topics(topic)
        if not matches:
            return f"Ainda não tenho esse tópico no meu currículo interno. Posso pesquisar na internet sobre '{topic}'."

        m = matches[0]
        return (
            f"{m['emoji']} **{m['topic']}** pertence ao domínio **{m['domain']}**.\n\n"
            f"Este é um dos tópicos do meu currículo. Posso explicar conceitos básicos, "
            f"ajudar com cálculos, simulações ou pesquisar material atualizado na internet.\n\n"
            f"Quer que eu explique algo específico sobre {m['topic']}?"
        )
