"""
Maria Core - Núcleo da assistente
"""
from .memory import Memory
from .search import WebSearch
from .knowledge import KnowledgeBase
from .agent import MariaAgent
from .self_improve import SelfImprovement

__all__ = ["Memory", "WebSearch", "KnowledgeBase", "MariaAgent", "SelfImprovement"]
