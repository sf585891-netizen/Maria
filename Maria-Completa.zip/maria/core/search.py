"""
Módulo de Pesquisa na Internet da Maria
Usa DuckDuckGo (sem chave de API).
"""
from typing import List, Dict, Optional
from duckduckgo_search import DDGS
import config


class WebSearch:
    def __init__(self):
        self.max_results = config.SEARCH_MAX_RESULTS

    def search(self, query: str, max_results: Optional[int] = None) -> List[Dict]:
        """
        Pesquisa na web e retorna resultados limpos.
        Cada resultado: title, href, body
        """
        max_results = max_results or self.max_results
        results = []
        try:
            with DDGS() as ddgs:
                raw = list(ddgs.text(query, max_results=max_results, region="br-pt"))
                for r in raw:
                    results.append({
                        "title": r.get("title", ""),
                        "url": r.get("href", ""),
                        "snippet": r.get("body", "")
                    })
        except Exception as e:
            print(f"[Pesquisa] Erro: {e}")
            results = [{
                "title": "Erro na pesquisa",
                "url": "",
                "snippet": f"Não foi possível pesquisar no momento: {str(e)}"
            }]
        return results

    def search_and_summarize(self, query: str) -> str:
        """Pesquisa e retorna um texto resumido pronto para a Maria usar."""
        results = self.search(query)
        if not results:
            return "Não encontrei resultados relevantes na internet."

        lines = [f"Resultados da pesquisa sobre: **{query}**\n"]
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. **{r['title']}**")
            lines.append(f"   {r['snippet']}")
            if r['url']:
                lines.append(f"   Fonte: {r['url']}")
            lines.append("")
        return "\n".join(lines)

    def needs_search(self, text: str) -> bool:
        """Heurística simples: quando a Maria deve pesquisar."""
        keywords = [
            "pesquisar", "busca", "procure", "o que é", "quem é",
            "quando foi", "atual", "hoje", "notícia", "preço",
            "última", "mais recente", "definição de"
        ]
        text_lower = text.lower()
        return any(k in text_lower for k in keywords)
