"""
Maria Agent - O cérebro da assistente
"""
from typing import Dict, List, Optional
from datetime import datetime
import re
import config
from .memory import Memory
from .search import WebSearch
from .knowledge import KnowledgeBase
from .self_improve import SelfImprovement
from hardware.devices import DeviceManager, DeviceType


class MariaAgent:
    def __init__(self):
        self.memory = Memory()
        self.search = WebSearch()
        self.knowledge = KnowledgeBase()
        self.self_improve = SelfImprovement()
        self.devices = DeviceManager()
        self.name = "Maria"
        self.version = config.MARIA_VERSION

    def _detect_intent(self, text: str) -> str:
        text_lower = text.lower().strip()

        if any(w in text_lower for w in ["currículo", "dominios", "o que você sabe", "áreas", "conhecimento"]):
            return "curriculum"
        if any(w in text_lower for w in ["memória", "o que você lembra", "histórico"]):
            return "memory"
        if any(w in text_lower for w in ["versão", "status", "quem é você", "sobre você"]):
            return "status"
        if any(w in text_lower for w in ["melhorar", "autoaperfeiçoamento", "propostas"]):
            return "self_improve"
        if any(w in text_lower for w in ["pesquisar", "busca", "procure", "o que é", "quem foi", "quando"]):
            return "search"
        if any(w in text_lower for w in ["robótica", "robô", "braço robótico", "drone", "slam"]):
            return "robotics"
        if any(w in text_lower for w in ["python", "código", "programar", "função", "bug", "erro no código"]):
            return "programming"
        if any(w in text_lower for w in ["explicar", "explique", "o que significa", "como funciona"]):
            return "explain"
        # Dispositivos / conexão
        if any(w in text_lower for w in [
            "dispositivo", "dispositivos", "conectar", "conecte", "conexão",
            "conectar em", "outros dispositivos", "porta serial", "listar portas",
            "escanear rede", "adicionar dispositivo", "desconectar"
        ]):
            return "devices"
        if text_lower in ["oi", "olá", "ola", "hey", "e aí", "eai", "bom dia", "boa tarde", "boa noite"]:
            return "greeting"
        if any(w in text_lower for w in ["ajuda", "help", "comandos", "o que você faz"]):
            return "help"
        return "chat"

    def _handle_greeting(self) -> str:
        return (
            f"Olá! ❤️ Eu sou a **Maria** (v{self.version}).\n\n"
            "Sou sua assistente de IA pessoal + plataforma de conhecimento + sistema de robótica.\n\n"
            "Posso conversar, pesquisar na internet, explicar ciência, ajudar com programação "
            "e, no futuro, controlar hardware com segurança.\n\n"
            "Digite **ajuda** para ver o que eu já sei fazer."
        )

    def _handle_help(self) -> str:
        return (
            "🤖 **Comandos e capacidades da Maria**\n\n"
            "• Converse normalmente comigo\n"
            "• **currículo** → veja meu currículo científico\n"
            "• **status** → versão e estado atual\n"
            "• **memória** → o que eu lembro das nossas conversas\n"
            "• **pesquisar [assunto]** → busco na internet\n"
            "• **explicar [tópico]** → explico conceitos do meu currículo\n"
            "• **melhorar** → sistema de autoaperfeiçoamento\n"
            "• **dispositivos** → listar / conectar outros dispositivos\n"
            "• **conectar [id]** → conectar a um dispositivo\n"
            "• **listar portas** → ver portas seriais USB\n"
            "• Pergunte sobre robótica, física, química, biologia, programação...\n\n"
            "Estou em constante evolução. Vamos construir juntos!"
        )

    def _handle_status(self) -> str:
        status = config.get_status()
        mem_stats = self.memory.stats()
        return (
            f"🤖 **Maria** — {status['codename']}\n"
            f"Versão: `{status['version']}`\n"
            f"Status: **{status['status']}**\n"
            f"Idioma: {status['language']}\n"
            f"Hardware: {status['hardware']}\n"
            f"Mensagens na memória: {mem_stats['total_messages']}\n"
            f"Fatos importantes: {mem_stats['important_facts']}\n"
            f"Timestamp: {status['timestamp']}"
        )

    def _handle_curriculum(self) -> str:
        return self.knowledge.get_curriculum_summary()

    def _handle_memory(self) -> str:
        stats = self.memory.stats()
        recent = self.memory.get_recent(5)
        lines = [
            f"🧠 **Memória da Maria**\n",
            f"Total de mensagens: {stats['total_messages']}",
            f"Fatos importantes: {stats['important_facts']}\n",
            "**Últimas mensagens:**"
        ]
        for m in recent:
            role = "Você" if m["role"] == "user" else "Maria"
            content = m["content"][:120] + ("..." if len(m["content"]) > 120 else "")
            lines.append(f"- {role}: {content}")
        return "\n".join(lines)

    def _handle_search(self, query: str) -> str:
        # Remove palavras de comando
        clean = re.sub(r"^(pesquisar|busca|procure|pesquise)\s+", "", query, flags=re.IGNORECASE).strip()
        if not clean:
            return "O que você quer que eu pesquise?"
        result = self.search.search_and_summarize(clean)
        self.memory.add_message("assistant", f"[Pesquisa realizada] {clean}", important=True)
        return result

    def _handle_explain(self, text: str) -> str:
        clean = re.sub(r"^(explicar|explique|o que é|o que significa|como funciona)\s+", "", text, flags=re.IGNORECASE).strip()
        if not clean:
            return "O que você quer que eu explique?"
        # Primeiro tenta no currículo interno
        explanation = self.knowledge.explain_topic(clean)
        # Se não encontrou bem, oferece pesquisa
        if "Ainda não tenho esse tópico" in explanation:
            return explanation + "\n\nQuer que eu pesquise na internet?"
        return explanation

    def _handle_self_improve(self) -> str:
        return self.self_improve.get_summary() + "\n\nPara propor uma melhoria, diga: **propor melhoria: [descrição]**"

    def _handle_programming(self, text: str) -> str:
        return (
            "💻 **Modo Programação ativado**\n\n"
            "Posso te ajudar com:\n"
            "• Python, JavaScript, C/C++, Java, Kotlin, HTML/CSS, SQL\n"
            "• Explicar código, encontrar bugs, sugerir melhorias\n"
            "• Escrever funções, scripts e automações\n"
            "• Boas práticas e testes\n\n"
            "Cole o código ou descreva o que precisa. Estou pronta!"
        )

    def _handle_robotics(self, text: str) -> str:
        return (
            "🤖 **Módulo de Robótica**\n\n"
            "Eu conheço:\n"
            "• Braços robóticos, cinemática e dinâmica\n"
            "• Robôs móveis, SLAM e navegação\n"
            "• Sensores, atuadores e controle (PID)\n"
            "• Drones e humanoides\n"
            "• Planejamento de movimento e manipulação\n\n"
            "No futuro poderei simular e controlar hardware real com segurança.\n"
            "O que você quer explorar?"
        )

    def _handle_devices(self, text: str) -> str:
        text_lower = text.lower().strip()

        # Listar dispositivos
        if any(w in text_lower for w in ["dispositivos", "listar dispositivos", "mostrar dispositivos", "quais dispositivos"]):
            return self.devices.summary()

        # Listar portas seriais
        if any(w in text_lower for w in ["listar portas", "portas seriais", "portas usb", "serial"]):
            ports = self.devices.scan_serial_ports()
            if not ports:
                return "Nenhuma porta serial encontrada ou pyserial indisponível."
            if "error" in ports[0]:
                return ports[0]["error"]
            lines = ["🔌 **Portas seriais detectadas:**\n"]
            for p in ports:
                lines.append(f"• `{p['device']}` — {p.get('description', 'sem descrição')}")
            lines.append("\nPara adicionar: **adicionar serial [porta] [nome]**")
            return "\n".join(lines)

        # Conectar a um dispositivo
        match = re.search(r"conectar(?:\s+em|\s+ao|\s+a)?\s+([a-zA-Z0-9\-_\.]+)", text_lower)
        if match or "conectar" in text_lower:
            device_id = match.group(1) if match else None
            if not device_id:
                return (
                    "Qual dispositivo você quer conectar?\n"
                    "Use: **conectar [id]**\n"
                    "Exemplo: `conectar esp32-sala`\n\n"
                    + self.devices.summary()
                )
            result = self.devices.connect(device_id)
            return result["message"]

        # Desconectar
        match = re.search(r"desconectar(?:\s+de)?\s+([a-zA-Z0-9\-_\.]+)", text_lower)
        if match:
            device_id = match.group(1)
            result = self.devices.disconnect(device_id)
            return result["message"]

        # Adicionar dispositivo de rede
        # Formato: adicionar dispositivo nome ip porta
        match = re.search(
            r"adicionar\s+(?:dispositivo\s+)?(\S+)\s+(\d{1,3}(?:\.\d{1,3}){3})(?:\s+(\d+))?",
            text_lower
        )
        if match:
            name, ip, port = match.group(1), match.group(2), match.group(3)
            port = int(port) if port else 80
            device_id = name.lower().replace(" ", "-")
            self.devices.add_device(
                device_id=device_id,
                name=name,
                device_type=DeviceType.NETWORK,
                address=ip,
                port=port
            )
            return (
                f"✅ Dispositivo **{name}** adicionado (`{device_id}`).\n"
                f"Endereço: {ip}:{port}\n\n"
                f"Agora diga: **conectar {device_id}**"
            )

        # Adicionar serial
        match = re.search(r"adicionar\s+serial\s+(\S+)(?:\s+(.+))?", text_lower)
        if match:
            port_path = match.group(1)
            name = match.group(2) or port_path
            device_id = name.lower().replace(" ", "-").replace("/", "-")
            self.devices.add_device(
                device_id=device_id,
                name=name,
                device_type=DeviceType.SERIAL,
                address=port_path,
                meta={"baudrate": 115200}
            )
            return (
                f"✅ Dispositivo serial **{name}** adicionado (`{device_id}`).\n"
                f"Porta: {port_path}\n\n"
                f"Diga: **conectar {device_id}**"
            )

        # Resposta padrão do módulo de dispositivos
        return (
            self.devices.summary()
            + "\n\n**Comandos úteis:**\n"
            "• `dispositivos` — listar todos\n"
            "• `conectar [id]` — conectar\n"
            "• `desconectar [id]` — desconectar\n"
            "• `listar portas` — ver portas USB/Serial\n"
            "• `adicionar dispositivo nome 192.168.1.50 80` — adicionar de rede\n"
            "• `adicionar serial /dev/ttyUSB0 meu-esp32` — adicionar serial\n\n"
            "🔒 Por segurança, conexões reais de hardware só funcionam se "
            "`HARDWARE_ENABLED = True` no config.py."
        )

    def process(self, user_input: str) -> str:
        if not user_input or not user_input.strip():
            return "Estou aqui. Pode falar comigo."

        user_input = user_input.strip()
        self.memory.add_message("user", user_input)

        intent = self._detect_intent(user_input)

        if intent == "greeting":
            response = self._handle_greeting()
        elif intent == "help":
            response = self._handle_help()
        elif intent == "status":
            response = self._handle_status()
        elif intent == "curriculum":
            response = self._handle_curriculum()
        elif intent == "memory":
            response = self._handle_memory()
        elif intent == "search":
            response = self._handle_search(user_input)
        elif intent == "explain":
            response = self._handle_explain(user_input)
        elif intent == "self_improve":
            response = self._handle_self_improve()
        elif intent == "programming":
            response = self._handle_programming(user_input)
        elif intent == "robotics":
            response = self._handle_robotics(user_input)
        elif intent == "devices":
            response = self._handle_devices(user_input)
        else:
            # Chat genérico + tenta usar conhecimento ou pesquisa se necessário
            response = self._generic_chat(user_input)

        self.memory.add_message("assistant", response)
        return response

    def _generic_chat(self, text: str) -> str:
        # Heurística: se parece pergunta de conhecimento, tenta currículo
        if "?" in text or text.lower().startswith(("o que", "como", "por que", "quando", "quem", "onde")):
            matches = self.knowledge.search_topics(text)
            if matches:
                m = matches[0]
                return (
                    f"Encontrei relação com **{m['topic']}** no domínio {m['emoji']} {m['domain']}.\n\n"
                    f"{self.knowledge.explain_topic(m['topic'])}\n\n"
                    "Quer que eu aprofunde ou pesquise mais na internet?"
                )
            # Se não, pesquisa
            if len(text) > 15:
                return self._handle_search(text)

        # Resposta padrão amigável
        return (
            "Entendi. Estou processando...\n\n"
            "Posso te ajudar melhor se você for mais específico. "
            "Exemplos:\n"
            "• \"explique cinemática inversa\"\n"
            "• \"pesquisar última notícia sobre fusão nuclear\"\n"
            "• \"me ajuda com um código Python\"\n"
            "• \"currículo\" para ver tudo que eu sei\n\n"
            "Estou aqui ❤️"
        )
