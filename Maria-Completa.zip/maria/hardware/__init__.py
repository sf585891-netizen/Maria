"""
Camada de Hardware da Maria
SEMPRE com segurança. Nunca liga motores diretamente.
"""
import config


class HardwareController:
    """
    Interface segura para hardware.
    Por padrão tudo desativado.
    """

    def __init__(self):
        self.enabled = config.HARDWARE_ENABLED
        self.allow_motors = config.ALLOW_MOTOR_CONTROL

    def status(self) -> str:
        if not self.enabled:
            return "Hardware DESATIVADO por segurança. Ative apenas com equipamentos reais e autorização."
        return "Hardware ATIVO (modo seguro)."

    def set_motor(self, motor_id: int, speed: float) -> str:
        if not self.enabled or not self.allow_motors:
            return "❌ Controle de motores desativado. Segurança em primeiro lugar."
        speed = max(-config.MAX_MOTOR_SPEED, min(config.MAX_MOTOR_SPEED, speed))
        # Aqui entraria a comunicação real (serial, MQTT, etc.)
        return f"Motor {motor_id} → velocidade {speed:.2f} (simulado)"

    def emergency_stop(self) -> str:
        return "🛑 PARADA DE EMERGÊNCIA acionada. Todos os atuadores desligados."
