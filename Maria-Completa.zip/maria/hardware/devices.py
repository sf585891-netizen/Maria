"""
Sistema de Conexão com Dispositivos da Maria
Permite descobrir, conectar e controlar outros dispositivos com segurança.
"""
import json
import socket
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from enum import Enum
import config

# Tentativa de importar pyserial (opcional)
try:
    import serial
    import serial.tools.list_ports
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False


class DeviceType(str, Enum):
    NETWORK = "network"       # HTTP / WebSocket / IP
    SERIAL = "serial"         # USB / UART
    BLUETOOTH = "bluetooth"   # Futuro
    VIRTUAL = "virtual"       # Simulado / outra Maria
    UNKNOWN = "unknown"


class DeviceStatus(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    BUSY = "busy"


class Device:
    def __init__(
        self,
        device_id: str,
        name: str,
        device_type: DeviceType,
        address: str,
        port: Optional[int] = None,
        meta: Optional[Dict] = None
    ):
        self.id = device_id
        self.name = name
        self.type = device_type
        self.address = address
        self.port = port
        self.meta = meta or {}
        self.status = DeviceStatus.DISCONNECTED
        self.last_seen = None
        self.last_error = None
        self.connection = None  # objeto de conexão real (socket, serial, etc.)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type.value,
            "address": self.address,
            "port": self.port,
            "status": self.status.value,
            "last_seen": self.last_seen,
            "last_error": self.last_error,
            "meta": self.meta
        }


class DeviceManager:
    """
    Gerenciador central de dispositivos da Maria.
    Tudo passa por aqui — nunca conecta direto sem segurança.
    """

    def __init__(self):
        self.devices: Dict[str, Device] = {}
        self.registry_file = config.DATA_DIR / "devices.json"
        self._load_registry()
        self._lock = threading.Lock()

        # Dispositivo virtual "outra Maria" de exemplo
        self._register_default_virtual()

    def _register_default_virtual(self):
        if "maria-local" not in self.devices:
            self.add_device(
                device_id="maria-local",
                name="Maria Local (esta instância)",
                device_type=DeviceType.VIRTUAL,
                address="127.0.0.1",
                port=8000,
                meta={"role": "self"}
            )
            self.devices["maria-local"].status = DeviceStatus.CONNECTED
            self.devices["maria-local"].last_seen = datetime.now().isoformat()

    def _load_registry(self):
        if self.registry_file.exists() and self.registry_file.stat().st_size > 0:
            try:
                with open(self.registry_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for d in data.get("devices", []):
                    dev = Device(
                        device_id=d["id"],
                        name=d["name"],
                        device_type=DeviceType(d.get("type", "unknown")),
                        address=d["address"],
                        port=d.get("port"),
                        meta=d.get("meta", {})
                    )
                    dev.status = DeviceStatus(d.get("status", "disconnected"))
                    dev.last_seen = d.get("last_seen")
                    self.devices[dev.id] = dev
            except Exception as e:
                print(f"[Devices] Erro ao carregar registro: {e}")

    def _save_registry(self):
        try:
            data = {
                "devices": [d.to_dict() for d in self.devices.values()],
                "updated": datetime.now().isoformat()
            }
            with open(self.registry_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Devices] Erro ao salvar registro: {e}")

    def add_device(
        self,
        device_id: str,
        name: str,
        device_type: DeviceType,
        address: str,
        port: Optional[int] = None,
        meta: Optional[Dict] = None
    ) -> Device:
        with self._lock:
            dev = Device(device_id, name, device_type, address, port, meta)
            self.devices[device_id] = dev
            self._save_registry()
            return dev

    def remove_device(self, device_id: str) -> bool:
        with self._lock:
            if device_id in self.devices and device_id != "maria-local":
                dev = self.devices[device_id]
                self._disconnect(dev)
                del self.devices[device_id]
                self._save_registry()
                return True
            return False

    def list_devices(self) -> List[Dict]:
        return [d.to_dict() for d in self.devices.values()]

    def get_device(self, device_id: str) -> Optional[Device]:
        return self.devices.get(device_id)

    def scan_serial_ports(self) -> List[Dict]:
        """Lista portas seriais disponíveis no sistema."""
        if not SERIAL_AVAILABLE:
            return [{"error": "pyserial não instalado"}]
        ports = []
        for p in serial.tools.list_ports.comports():
            ports.append({
                "device": p.device,
                "description": p.description,
                "hwid": p.hwid,
                "manufacturer": getattr(p, "manufacturer", None)
            })
        return ports

    def scan_local_network(self, base_ip: str = "192.168.1", ports: List[int] = None) -> List[Dict]:
        """
        Varredura simples de hosts na rede local (portas comuns de IoT / Maria).
        CUIDADO: use apenas em redes que você controla.
        """
        if ports is None:
            ports = [80, 443, 8000, 8080, 1883, 5000]

        found = []
        # Escaneia apenas .1 a .20 para não demorar muito
        for i in range(1, 21):
            ip = f"{base_ip}.{i}"
            for port in ports:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(0.25)
                    result = sock.connect_ex((ip, port))
                    sock.close()
                    if result == 0:
                        found.append({"ip": ip, "port": port, "status": "open"})
                except Exception:
                    pass
        return found

    def connect(self, device_id: str) -> Dict[str, Any]:
        """Tenta conectar a um dispositivo registrado."""
        dev = self.get_device(device_id)
        if not dev:
            return {"ok": False, "message": f"Dispositivo '{device_id}' não encontrado."}

        if not config.HARDWARE_ENABLED and dev.type != DeviceType.VIRTUAL:
            return {
                "ok": False,
                "message": (
                    "🔒 Hardware e conexões externas estão DESATIVADOS por segurança.\n"
                    "Para ativar, edite config.py → HARDWARE_ENABLED = True\n"
                    "(só faça isso se souber o que está fazendo e em rede confiável)."
                )
            }

        with self._lock:
            dev.status = DeviceStatus.CONNECTING
            try:
                if dev.type == DeviceType.VIRTUAL:
                    # Sempre "conectado" consigo mesma
                    dev.status = DeviceStatus.CONNECTED
                    dev.last_seen = datetime.now().isoformat()
                    dev.last_error = None
                    self._save_registry()
                    return {"ok": True, "message": f"Conectado a {dev.name}."}

                elif dev.type == DeviceType.NETWORK:
                    return self._connect_network(dev)

                elif dev.type == DeviceType.SERIAL:
                    return self._connect_serial(dev)

                else:
                    dev.status = DeviceStatus.ERROR
                    dev.last_error = "Tipo de dispositivo ainda não suportado"
                    return {"ok": False, "message": dev.last_error}

            except Exception as e:
                dev.status = DeviceStatus.ERROR
                dev.last_error = str(e)
                self._save_registry()
                return {"ok": False, "message": f"Erro ao conectar: {e}"}

    def _connect_network(self, dev: Device) -> Dict:
        """Testa conexão TCP simples + opcional HTTP health."""
        port = dev.port or 80
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((dev.address, port))
            sock.close()

            if result == 0:
                dev.status = DeviceStatus.CONNECTED
                dev.last_seen = datetime.now().isoformat()
                dev.last_error = None
                self._save_registry()
                return {
                    "ok": True,
                    "message": f"✅ Conectado a {dev.name} ({dev.address}:{port})"
                }
            else:
                dev.status = DeviceStatus.ERROR
                dev.last_error = f"Porta {port} fechada ou host inacessível"
                self._save_registry()
                return {"ok": False, "message": f"❌ Não consegui alcançar {dev.address}:{port}"}
        except Exception as e:
            dev.status = DeviceStatus.ERROR
            dev.last_error = str(e)
            self._save_registry()
            return {"ok": False, "message": f"Erro de rede: {e}"}

    def _connect_serial(self, dev: Device) -> Dict:
        if not SERIAL_AVAILABLE:
            return {"ok": False, "message": "pyserial não está disponível neste sistema."}
        try:
            baud = dev.meta.get("baudrate", 115200)
            ser = serial.Serial(dev.address, baudrate=baud, timeout=1)
            dev.connection = ser
            dev.status = DeviceStatus.CONNECTED
            dev.last_seen = datetime.now().isoformat()
            dev.last_error = None
            self._save_registry()
            return {"ok": True, "message": f"✅ Conectado via serial em {dev.address} ({baud} baud)"}
        except Exception as e:
            dev.status = DeviceStatus.ERROR
            dev.last_error = str(e)
            self._save_registry()
            return {"ok": False, "message": f"Erro serial: {e}"}

    def disconnect(self, device_id: str) -> Dict:
        dev = self.get_device(device_id)
        if not dev:
            return {"ok": False, "message": "Dispositivo não encontrado."}
        if device_id == "maria-local":
            return {"ok": False, "message": "Não posso desconectar de mim mesma."}
        with self._lock:
            self._disconnect(dev)
            self._save_registry()
        return {"ok": True, "message": f"Desconectado de {dev.name}."}

    def _disconnect(self, dev: Device):
        if dev.connection:
            try:
                if hasattr(dev.connection, "close"):
                    dev.connection.close()
            except Exception:
                pass
            dev.connection = None
        dev.status = DeviceStatus.DISCONNECTED

    def send_command(self, device_id: str, command: str) -> Dict:
        """Envia um comando simples para o dispositivo (texto)."""
        dev = self.get_device(device_id)
        if not dev:
            return {"ok": False, "message": "Dispositivo não encontrado."}
        if dev.status != DeviceStatus.CONNECTED:
            return {"ok": False, "message": f"Dispositivo {dev.name} não está conectado."}

        if not config.HARDWARE_ENABLED and dev.type != DeviceType.VIRTUAL:
            return {"ok": False, "message": "🔒 Comandos para hardware externo desativados."}

        try:
            if dev.type == DeviceType.SERIAL and dev.connection:
                dev.connection.write((command + "\n").encode("utf-8"))
                time.sleep(0.1)
                response = ""
                if dev.connection.in_waiting:
                    response = dev.connection.read(dev.connection.in_waiting).decode("utf-8", errors="ignore")
                return {"ok": True, "message": f"Comando enviado.", "response": response or "(sem resposta)"}

            elif dev.type == DeviceType.NETWORK:
                # Exemplo: envia via HTTP POST simples (pode expandir depois)
                import urllib.request
                url = f"http://{dev.address}:{dev.port or 80}/command"
                data = json.dumps({"command": command}).encode("utf-8")
                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
                try:
                    with urllib.request.urlopen(req, timeout=3) as resp:
                        body = resp.read().decode("utf-8")
                    return {"ok": True, "message": "Comando enviado via rede.", "response": body}
                except Exception as e:
                    return {"ok": False, "message": f"Falha ao enviar comando: {e}"}

            elif dev.type == DeviceType.VIRTUAL:
                return {"ok": True, "message": f"[Virtual] Comando '{command}' recebido por {dev.name}."}

            return {"ok": False, "message": "Tipo de dispositivo não suporta comando ainda."}
        except Exception as e:
            return {"ok": False, "message": f"Erro ao enviar comando: {e}"}

    def summary(self) -> str:
        total = len(self.devices)
        connected = sum(1 for d in self.devices.values() if d.status == DeviceStatus.CONNECTED)
        lines = [
            f"🔌 **Dispositivos da Maria**",
            f"Total registrados: {total}",
            f"Conectados agora: {connected}",
            f"Hardware externo: {'ATIVADO' if config.HARDWARE_ENABLED else 'DESATIVADO (segurança)'}",
            "",
            "**Lista:**"
        ]
        for d in self.devices.values():
            icon = "🟢" if d.status == DeviceStatus.CONNECTED else "🔴"
            port_str = f":{d.port}" if d.port else ""
            lines.append(f"{icon} `{d.id}` — {d.name} ({d.type.value}) → {d.address}{port_str}")
        return "\n".join(lines)
