"""
Maria — Assistente IA Pessoal + Plataforma de Conhecimento + Sistema de Robótica
Ponto de entrada principal.
"""
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from pathlib import Path
import uvicorn
import config
from core.agent import MariaAgent

app = FastAPI(
    title="Maria",
    description="Assistente IA Pessoal + Conhecimento + Robótica",
    version=config.MARIA_VERSION
)

BASE_DIR = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Instância global do agente
maria = MariaAgent()


class ChatRequest(BaseModel):
    message: str


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/api/chat")
async def chat(req: ChatRequest):
    try:
        response = maria.process(req.message)
        return JSONResponse({"response": response, "status": "ok"})
    except Exception as e:
        return JSONResponse(
            {"response": f"Ocorreu um erro interno: {str(e)}", "status": "error"},
            status_code=500
        )


@app.get("/api/status")
async def status():
    return config.get_status()


@app.get("/api/memory")
async def memory_stats():
    return maria.memory.stats()


@app.get("/api/curriculum")
async def curriculum():
    return {"domains": maria.knowledge.list_domains()}


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": config.MARIA_VERSION}


@app.get("/api/devices")
async def list_devices():
    return {"devices": maria.devices.list_devices()}


@app.post("/api/devices/connect/{device_id}")
async def connect_device(device_id: str):
    result = maria.devices.connect(device_id)
    return result


@app.post("/api/devices/disconnect/{device_id}")
async def disconnect_device(device_id: str):
    result = maria.devices.disconnect(device_id)
    return result


@app.get("/api/devices/serial")
async def list_serial():
    return {"ports": maria.devices.scan_serial_ports()}


if __name__ == "__main__":
    print("=" * 50)
    print(f"  🤖 MARIA v{config.MARIA_VERSION} — {config.MARIA_CODENAME}")
    print("=" * 50)
    print("  Interface: http://127.0.0.1:8000")
    print("  Status:   ONLINE")
    print("  Hardware: DESATIVADO (segurança)")
    print("  Dispositivos: prontos para conexão")
    print("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
