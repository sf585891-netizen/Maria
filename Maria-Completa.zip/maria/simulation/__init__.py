"""
Módulo de Simulação da Maria
Antes de qualquer hardware físico, simulamos.
"""
from typing import Dict, Any
import math


class SimpleSimulator:
    """Simulador básico de braço 2D (exemplo)."""

    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = l1
        self.l2 = l2
        self.theta1 = 0.0
        self.theta2 = 0.0

    def set_joints(self, theta1: float, theta2: float):
        self.theta1 = theta1
        self.theta2 = theta2

    def end_effector(self) -> Dict[str, float]:
        x = self.l1 * math.cos(self.theta1) + self.l2 * math.cos(self.theta1 + self.theta2)
        y = self.l1 * math.sin(self.theta1) + self.l2 * math.sin(self.theta1 + self.theta2)
        return {"x": round(x, 4), "y": round(y, 4)}

    def step(self, d_theta1: float, d_theta2: float) -> Dict[str, Any]:
        self.theta1 += d_theta1
        self.theta2 += d_theta2
        return {
            "joints": {"theta1": round(self.theta1, 4), "theta2": round(self.theta2, 4)},
            "end_effector": self.end_effector()
        }
